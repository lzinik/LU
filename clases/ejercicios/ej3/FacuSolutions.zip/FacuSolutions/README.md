# jquery Exercises

Repo para los ejercicios de LU de la clase del 6/6

Ejercicios básicos de jQuery:

https://www.w3resource.com/jquery-exercises/

Normalize.css :
https://necolas.github.io/normalize.css/

Font Awesome :
https://fontawesome.com/